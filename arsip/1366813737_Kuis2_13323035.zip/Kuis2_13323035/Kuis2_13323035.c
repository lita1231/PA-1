

#include <stdio.h>
#include <stdlib.h>

void inputArray(int Array[], int N) {
    int i;
    for (i = 0; i < N; i++) {
        scanf("%d", &Array[i]);
    }
}

void printArray(int Array[], int N) {
    int i;

    for (i = 0; i < N; i++) {
        
            printf("%d ", Array[i]);
        
    }
    printf("\n");
}

void insertionSort(int Array[], int N) {
    int i, j, key;

    for (i = 1; i < N; i++) {
        key = Array[i];
        j = i - 1;

        while (j >= 0 && key < Array[j]) {
            Array[j + 1] = Array[j];
            j = j - 1;
        }
        Array[j + 1] = key;

        printf("Pass-%d: ", i);
        printArray(Array, N);
    }
}

void insertionSortganjil(int Array[], int N) {
    int i, j, key;

    for (i = 1; i < N; i++) {
        key = Array[i];
        j = i - 1;

        while (j >= 0 && key < Array[j]) {
            Array[j + 1] = Array[j];
            j = j - 1;
        }
        Array[j + 1] = key;

        printf("Pass-%d: ", i);
        printArray(Array, N);
    }
}

void insertionSortgenap(int Array[], int N) {
    int i, j, key;

    for (i = 1; i < N; i++) {
        key = Array[i];
        j = i - 1;

        while (j >= 0 && key < Array[j]) {
            Array[j + 1] = Array[j];
            j = j - 1;
        }
        Array[j + 1] = key;

        printf("Pass-%d: ", i);
        printArray(Array, N);
    }
}

int main() {
    int Array[100], Arrayganjil[100], Arraygenap[100];
    int ganjil = 0, genap = 0;
    int i, N;

    printf("Masukkan Jumlah Data Array: ");
    scanf("%d", &N);
    printf("Masukkan %d Element pada Array: ", N);
    inputArray(Array, N);
    printf("Data Array Sebelum Proses Insertion Sort: ");
    printArray(Array, N);

    for (i = 0; i < N; i++) {
        if (Array[i] % 2 == 0 && Array[i] > 0 && Array[i] < 100) { 
            Arraygenap[genap] = Array[i];
            genap++;
        } else if (Array[i] % 2 != 0 && Array[i] > 0 && Array[i] < 100) { 
            Arrayganjil[ganjil] = Array[i];
            ganjil++;
        }
    }

    printf("Data Array Genap Setelah Proses Insertion Sort: \n");
    insertionSortgenap(Arraygenap, genap);
    printf("Data Array Ganjil Setelah Proses Insertion Sort: \n");
    insertionSortganjil(Arrayganjil, ganjil);

    return 0;
}
