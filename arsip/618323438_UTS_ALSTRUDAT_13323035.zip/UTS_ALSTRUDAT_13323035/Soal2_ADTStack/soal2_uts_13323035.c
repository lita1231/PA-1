/*
Nim     : 13323035
Nama    : Glen Rifael Situmorang
Nama Program : Driver Stack
*/
#include "stack.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
    STACK S;
    int i, j;
    int T, pops, index, size;
    int *N;

    printf("Masukkan Size Stack : ");
    scanf("%d", &size);
    N = (int *)malloc(size * sizeof(int));

    CreateEmpty(&S, size);

    printf("Push nilai elemen STACK: \n");
    i = 0;
    do
    {
        scanf("%d", &S.T[i]);
        if (S.T[i] == -99)
        {
            system("exit");
        }
        else
        {
            Push(&S, S.T[i]);
            i++;
        }
    } while (i < S.MaxEL && S.T[i] != -99);

    printf("\nIsi Stack : ");
    for (i = S.MaxEL - 1; i >= 0; i--)
    {
        if (S.T[i] != -99)
        {
            printf("%d ", S.T[i]);
        }
        else
        {
            continue;
        }
    }
    printf("\nNilai Top = %d\n", S.T[S.TOP]);
    if (IsFull(S) == 1)
    {
        printf("Status Stack : Full");
    }
    else if (IsEmpty(S) == 1)
    {
        printf("Status Stack : Empty");
    }
    else
    {
        printf("Status Stack : Not Full & Not Empty");
    }

    int minus = 0;
    int tot = 0;
    for (i = S.TOP + 1; i >= 0; i--)
    {
        if (S.T[i] < 0)
        {
            pops = S.T[i];
            printf("\nNilai Minus : %d\n", pops);
            minus = 1;
            Pop(&S, &pops);
            tot++;
        }
    }
    if (!minus)
    {
        printf("Nilai Minus : - \n");
    }

    printf("Setelah Proses Pop Nilai Minus: ");
    printf("\nIsi Stack : ");
    for (i = S.TOP + tot; i >= 0; i--)
    {
        if (S.T[i] < 0)
        {
            continue;
        }
        else
            printf("%d ", S.T[i]);
    }
    printf("\n");
    free(N);
    return 0;
}

// printf("\n\nMasukkan Jumlah Elemen Yang Akan Dihapus (Pop):");
// scanf("%d", &pops);

// for (i = 0; i < pops; i++)
// {
//     int X = S.T[i];
//     Pop(&S, &X);
// }

// printf("\nIsi Stack : ");
// for (i = S.TOP; i >= 0; i--)
// {
//     printf("%d", S.T[i]);
// }
// printf("\nNilai Top = %d\n", S.T[S.TOP]);
// if (IsFull(S) == 1)
// {
//     printf("Status Stack: Full");
// }
// else if (IsEmpty(S) == 1)
// {
//     printf("Status Stack: Empty");
// }
// else
// {
//     printf("Status Stack: Not Full & Not Empty");
// }

// free(N);
// }

// printf("\n\nMasukkan Jumlah Elemen Yang Akan Dihapus (Pop): ");
// scanf("%d", &Pop);

// for (i = 0; i < Pop; i++)
// {
//     int x = S.T[i];
//     Pop(&S, &x);
// }

// printf("\nIsi Stack : ");
// for (i = S.TOP; i >= 0; i--)
// {
//     printf("%ld ", S.T[i]);
// }
// printf("\nNilai Top = %d\n", S.T[S.TOP]);