/*
Nim     : 13323035
Nama    : Glen Rifael Situmorang
Nama Program : Header Stack
*/
#ifndef STACK_H
#define STACK_H

#define boolean unsigned char
#define true 1
#define false 0
#define Nil -99

typedef int infotypes;
typedef int address;

typedef struct
{
    infotypes *T;
    address TOP;
    int MaxEL;
} STACK;

void CreateEmpty(STACK *S, int MaxEl);
void DeAlokasi(STACK *S);
boolean IsEmpty(STACK S);
boolean IsFull(STACK S);

void Push(STACK *S, infotypes X);

void Pop(STACK *S, infotypes *X);
void Iterate(STACK S);

#endif