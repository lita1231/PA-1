/*
Nim     : 13323035
Nama    : Glen Rifael Situmorang
Nama Program : Implementasi Stack
*/
#include "stack.h"
#include <stdio.h>
#include <stdlib.h>

void CreateEmpty(STACK *S, int MaxEl)
{
    S->T = (infotypes *)malloc(MaxEl * sizeof(infotypes));
    S->MaxEL = MaxEl;
    S->TOP = Nil;
}

void DeAlokasi(STACK *S)
{
    free(S->T);
    S->MaxEL = 0;
}

boolean IsEmpty(STACK S)
{
    if (S.TOP == Nil || S.MaxEL == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
boolean IsFull(STACK S)
{
    if (S.TOP == S.MaxEL - 1)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void Push(STACK *S, infotypes X)
{
    if (!IsEmpty(*S))
    {
        S->TOP++;
    }
    else
    {
        S->TOP = 0;
    }
    S->T[S->TOP] = X;
}

void Pop(STACK *S, infotypes *X)
{
    *X = S->T[S->TOP];
    if (S->TOP == 0)
    {
        S->TOP = Nil;
    }
    else
    {
        S->TOP--;
    }
}
void Iterate(STACK S)
{
    int i;
    if (!IsEmpty(S))
    {
        for (i = S.TOP; i >= 0; i++)
            printf("%ld ", S.T[i]);
    }
}