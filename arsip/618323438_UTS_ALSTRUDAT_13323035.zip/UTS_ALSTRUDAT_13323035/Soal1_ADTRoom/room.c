/*
Nim     : 13323035
Nama    : Glen Rifael Situmorang
Nama Program : room.c
*/
#include <stdio.h>
#include "room.h"

int main() {
    ROOM r;
    r = MakeROOM(1, "GD516", 5.5, 8.5, 70);
    TulisROOM(&r);

    printf("\n");

    printf("Masukkan data ruangan:\n");
    BacaROOM(&r);
    TulisROOM(&r);

    return 0;
}