/*
Nim     : 13323035
Nama    : Glen Rifael Situmorang
Nama Program : mroom.c
*/
#include "room.h"

ROOM MakeROOM (int kode,char *a, float b, float c, int d) {
    ROOM R;
    R.kode = kode;
    R.name = a;
    R.panjang = b;
    R.lebar = c;
    R.kapasitas = d;
    return R;
}

void BacaROOM (ROOM * R) {
    scanf("%d", &(R->kode));
    char name[100];
    scanf("%s", name);
    R->name = strdup(name);
    scanf("%f", &(R->panjang));
    scanf("%f", &(R->lebar));
    scanf("%d", &(R->kapasitas));
}

void TulisROOM (ROOM *R) {
    printf("Kode : %d\n", R->kode);
    printf("Deskripsi : Ruangan %s dengan Luas %.2f satuan luas memiliki kapasitas\n", R->name, R->panjang * R->lebar, R->kapasitas);
}