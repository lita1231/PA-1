/*
NIM              :13323035
Nama             :Glen Rifael Situmorang
Nama Program     :Program ADT Stack
*/
#ifndef QUEUE_H
#define QUEUE_H

#define boolean unsigned char
#define true 1
#define false 0
#define Nil -99
#define MaxEl 10
typedef int infotype;
typedef int address;

typedef struct
{
    infotype T[MaxEl];
    address TOP;
} Stack;

void CreateEmpty(Stack *S);

boolean IsEmpty(Stack S);

boolean IsFull(Stack S);

void Push(Stack *S, infotype X);

void Pop(Stack *S, infotype *X);

#endif