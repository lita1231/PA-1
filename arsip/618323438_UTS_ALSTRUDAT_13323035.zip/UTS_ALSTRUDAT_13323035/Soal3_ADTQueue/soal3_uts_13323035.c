/*
NIM              :13323035
Nama             :Glen Rifael Situmorang
Nama Program     :Program ADT Stack
*/

#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main()
{
    // Variabel
    Stack S;
    int i, j;
    int N, pop, index;
    int T[10];
    // Algoritma
    CreateEmpty(&S);
    printf("Money : \n");
    i = 0;
    do
    {
        scanf("%d", &T[i]);
        if (T[i] == -99)
        {
            system("exit");
        }
        else
        {
            Push(&S, T[i]);
            i++;
        }

    } while (i < 10 && T[i] != -99);

    printf("\nqueue : ");
    for (i = S.TOP; i >= 0; i--)
    {
        printf("%d ", S.T[i]);
    }

    printf("\nTransaksi_atm = %d\n", S.T[S.TOP]);
    if (IsFull(S) == 1)
    {
        printf("Status = Antrian ATM penuh");
    }
    else if (IsEmpty(S) == 1)
    {
        printf("Status = Antrian ATM masih bisa diisi");
    }
    else
    {
        printf("Status : Antrian Penuh");
    }

    printf("\nSisa ATM : ");
    for (i = S.TOP; i >= 0; i--)
    {
        printf("%ld ", S.T[i]);
    }
    printf("\nSisa Antrian = %d\n", S.T[S.TOP]);
}