/*
    Nama    : Glen Rifael Situmorang
    NIM     : 13323035
    Kelas   : D3 Teknologi Komputer
*/

#include <stdio.h>
#include <stdlib.h>

void insertionSort(int Array[], int N)
{
    int i, j, key, k;
    for (i = 1; i < N; i++)
    {
        key = Array[i];
        j = i - 1;
        while (j >= 0 && key < Array[j])
        {
            Array[j + 1] = Array[j];
            j = j - 1;
        }
        Array[j + 1] = key;
    }
}

void inputArray(int Array[], int N)
{
    int i;
    for (i = 0; i < N; i++)
    {
        scanf("%d", &Array[i]);
    }
}

void printArray(int Array[], int N)
{
    int i;
    for (i = 0; i < N; i++)
    {
        printf("%d ", Array[i]);
    }
    printf("\n");
}

void separateArray(int Array[], int N, int evenArray[], int oddArray[], int *evenSize, int *oddSize)
{
    *evenSize = 0;
    *oddSize = 0;

    for (int i = 0; i < N; i++)
    {
        if (Array[i] % 2 == 0)
        {
            evenArray[*evenSize] = Array[i];
            (*evenSize)++;
        }
        else
        {
            oddArray[*oddSize] = Array[i];
            (*oddSize)++;
        }
    }
}

int main()
{
    int Array[100];
    int evenArray[100], oddArray[100];
    int evenSize, oddSize;
    int i, N;

    printf("Enter Number of Array: ");
    scanf("%d", &N);
    printf("Enter %d Element Array: ", N);
    inputArray(Array, N);

    separateArray(Array, N, evenArray, oddArray, &evenSize, &oddSize);

    printf("\nOriginal Sequence: ");
    printArray(Array, N);

    printf("\nSorted using Insertion Sort: ");
    insertionSort(Array, N);
    printArray(Array, N);

    printf("\nEven Numbers: ");
    printArray(evenArray, evenSize);

    printf("Odd Numbers: ");
    printArray(oddArray, oddSize);

    return 0;
}
