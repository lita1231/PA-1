/*
    Nama    : Glen Rifael Situmorang
    NIM     : 13323035
    Kelas   : D3 Teknologi Komputer
*/
#include <stdio.h>
#include <stdlib.h>

void selectionSort(int Array[], int N)
{
    int i, j, min_idx, temp, k;
    for (i = 0; i < N - 1; i++)
    {
        min_idx = i;
        for (j = i + 1; j < N; j++)
        {
            if (Array[j] < Array[min_idx])
            {
                min_idx = j;
            }
        }
        temp = Array[i];
        Array[i] = Array[min_idx];
        Array[min_idx] = temp;
    }
}

void inputArray(int Array[], int N)
{
    int i;
    for (i = 0; i < N; i++)
    {
        scanf("%d", &Array[i]);
    }
}

void printArray(int Array[], int N)
{
    int i;
    for (i = 0; i < N; i++)
    {
        printf("%d ", Array[i]);
    }
    printf("\n");
}

int main()
{
    int N, i;
    int Array[100];
    printf("Enter Number of Elements: ");
    scanf("%d", &N);

    printf("Enter %d Elements: ", N);
    inputArray(Array, N);

    printf("Original Sequence: ");
    printArray(Array, N);

    printf("Sorted using Selection Sort: \n");

    for (i = 1; i < N; i++)
    {

        printf("press-%d: ", i);
        selectionSort(Array, i + 1);
        printArray(Array, N);
    }
    return 0;
}